import React, { useState } from "react";
import InquiryForm from "./InquiryForm";

function App() {
  const [response, setResponse] = useState("");

  const handleInquirySubmit = (userMessage) => {
    fetch("http://127.0.0.1:8000/inquiry", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message: userMessage }),
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error(`Request failed with status ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        setResponse(data.response);
      })
      .catch((error) => {
        setResponse("Error: " + error.message);
      });
  };

  return (
    <div style={{ padding: "40px", textAlign: "center", fontFamily: "Arial, sans-serif" }}>
      <h1 style={{ marginBottom: "20px" }}>Customer Service Agent</h1>
      <InquiryForm onSubmit={handleInquirySubmit} />
      {response && (
        <div
          style={{
            marginTop: "30px",
            padding: "20px",
            backgroundColor: "#f8f8f8",
            borderRadius: "8px",
            maxWidth: "600px",
            marginLeft: "auto",
            marginRight: "auto",
            boxShadow: "0 0 10px rgba(0, 0, 0, 0.05)",
          }}
        >
          <h2>Response:</h2>
          <p>{response}</p>
        </div>
      )}
    </div>
  );
}

export default App;
